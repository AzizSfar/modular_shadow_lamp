"""Keep geometric regressions explicit when the app's startup preset changes."""
import re
from prepare_svg import ROOT, set_value


def baseline_text():
    source=(ROOT/'modular_shadow_lamp.scad').read_text(encoding='utf-8')
    values={'Cylinder_diameter':100,'Cylinder_height':30,'Wall_thickness':2,
            'Shadow_length':300,'Wall_standoff':0,'Minimum_web_width':0,
            'Automatic_bridges_only':False,'Bridge_width':0.8,'Housing_shape':'Cylinder',
            'Artwork_source':'Automatic','Svg_file':'default.svg','Embedded_artwork':False,
            'Embedded_surface_repair':False,'Embedded_surface_signature':[],
            'Embedded_bridge_segments':[],'Embedded_bridge_angles':[],'Embedded_removed_islands':[],
            'Embedded_radius_factor':0.7071067811865476}
    for name,value in values.items(): source=set_value(source,name,value)
    source=re.sub(r'// BEGIN EMBEDDED ARTWORK.*?// END EMBEDDED ARTWORK',
        '// BEGIN EMBEDDED ARTWORK\nmodule embedded_artwork() { square(1,center=true); }\n// END EMBEDDED ARTWORK',source,flags=re.S)
    source=re.sub(r'// BEGIN EMBEDDED PRINT LIGHT.*?// END EMBEDDED PRINT LIGHT',
        '// BEGIN EMBEDDED PRINT LIGHT\nmodule embedded_print_light() {}\n// END EMBEDDED PRINT LIGHT',source,flags=re.S)
    return source


BASELINE=ROOT/'output'/'regression_baseline.scad'
BASELINE.parent.mkdir(exist_ok=True)
BASELINE.write_text(baseline_text(),encoding='utf-8')
